WORLD CRICKET LIVE — Android APK source project

یہ Android app کا سورس پروجیکٹ ہے، تیار شدہ APK نہیں۔ اس ماحول میں Android SDK/Gradle موجود نہیں، اس لیے APK یہاں compile نہیں ہو سکی۔

APK حاصل کرنے کا آسان cloud طریقہ:
1) GitHub پر اکاؤنٹ بنائیں/لاگ اِن کریں۔
2) اس ZIP کو extract کریں اور اس کے اندر موجود تمام فائلیں ایک نئے GitHub repository میں upload کریں۔
3) GitHub repository میں Actions کھولیں۔ اگر workflow خود نہ چلے تو “Build Android APK” منتخب کرکے “Run workflow” دبائیں۔
4) Build مکمل ہونے کے بعد Actions کے run میں “World-Cricket-Live-APK” artifact ڈاؤن لوڈ کریں۔
5) ZIP extract کرکے app-debug.apk اپنے Android فون پر کھولیں اور install کریں۔ اگر Android اجازت مانگے تو اسی فائل/براؤزر کے لیے Install unknown apps کی اجازت دیں۔

اہم: ایپ میں فی الحال صرف نمونہ (demo) اسکور ہیں، حقیقی live scores نہیں۔ حقیقی live scores کے لیے licensed cricket scores API اور API key درکار ہے۔ Demo scores کو حقیقی live نہ سمجھیں۔
